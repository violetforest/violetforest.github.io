const fullscreen = document.getElementsByClassName("fullscreen")[0];
var link = null;

document.addEventListener("DOMContentLoaded", () => {
    new cursoreffects.trailingCursor({ element: fullscreen });
});